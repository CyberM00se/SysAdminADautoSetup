# Script: install-adds.ps1
# Author: Dylan 'Chromosome' Navarro
# Description: This script is designed to install and configure the Active Directory Domain Services role on a Windows Server.

$domainName = Read-Host "What would you like your domain name to be?: "
Write-Host "Installing the ADDS..."
Add-WindowsFeature AD-Domain-Services
Write-Host "Done."
Write-Host "Installing the ADDS Tools"  # This shit dont work. Need to re add
Write-Host "Done."
Write-Host "Configuring ADDS and DNS"
Install-ADDSForest -DomainName $domainName -InstallDNS
Write-Host "Done."
Read-Host ("Press any key to exit....")